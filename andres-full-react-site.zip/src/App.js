import React from 'react';
import AboutPage from './AboutPage';

function App() {
  return <AboutPage />;
}

export default App;
